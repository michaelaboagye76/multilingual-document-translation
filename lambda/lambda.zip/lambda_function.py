import boto3
import json
import os

s3 = boto3.client("s3")
translate = boto3.client("translate")

OUTPUT_BUCKET = os.environ.get("OUTPUT_BUCKET", "doc-translated-response")

def lambda_handler(event, context):
    """
    Trigger: S3 -> JSON file upload
    Workflow:
      1. Download JSON file from input bucket
      2. Parse metadata: source_lang, target_langs, text_blocks
      3. Call AWS Translate on each text block
      4. Save translations into new JSON
      5. Upload result JSON to output bucket
    """

    # 1 Gets file info from event
    for record in event["Records"]:
        bucket = record["s3"]["bucket"]["name"]
        key = record["s3"]["object"]["key"]

        print(f"Processing file: s3://{bucket}/{key}")

        # 2 Download the JSON file
        tmp_file = f"/tmp/{os.path.basename(key)}"
        s3.download_file(bucket, key, tmp_file)

        with open(tmp_file, "r") as f:
            input_data = json.load(f)

        # Expected JSON structure:
        # {
        #   "source_lang": "en",
        #   "target_langs": ["fr", "es", "de"],
        #   "text_blocks": ["Hello world", "This is AWS Translate"]
        # }

        source_lang = input_data.get("source_lang", "auto")
        target_langs = input_data.get("target_langs", [])
        text_blocks = input_data.get("text_blocks", [])

        results = {
            "source_lang": source_lang,
            "translations": {}
        }

        # 3 Translate each block for each target language
        for target_lang in target_langs:
            translations = []
            for block in text_blocks:
                response = translate.translate_text(
                    Text=block,
                    SourceLanguageCode=source_lang,
                    TargetLanguageCode=target_lang
                )
                translations.append(response["TranslatedText"])

            results["translations"][target_lang] = translations

        # 4 Save result JSON
        result_key = key.replace(".json", f"-translated.json")
        tmp_out = f"/tmp/{os.path.basename(result_key)}"

        with open(tmp_out, "w") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

        # 5. Upload results to response bucket
        s3.upload_file(tmp_out, OUTPUT_BUCKET, result_key)

        print(f"✅ Translations saved to s3://{OUTPUT_BUCKET}/{result_key}")

    return {"statusCode": 200, "body": "Translation complete"}
